# BHAWANI BUSINESS ERP — Phase 1

Free React + TypeScript responsive demo, designed for mobile and desktop.

## Run

1. Install Node.js 20+.
2. Open this folder in a terminal.
3. Run `npm install`.
4. Run `npm run dev` and open the shown URL.
5. For a production build, run `npm run build`.

## Included
- Responsive dark dashboard, company selector (UI only)
- Product Master: add products with price and stock
- Quantum POS starter: add items to cart, save a local demo sale, automatically reduce local stock
- Recent sales, sales register and stock register
- Browser localStorage persistence on the **same device and browser only**

## Important limitations
This is a **prototype**, not a secure production ERP. There is no server, authentication, GST invoice, real company isolation, purchases, expense recording, cloud sync, backups, or real AI yet. Company selection is a visual selector only and does not isolate data. Do not use for real financial records until a backend, access controls, and backup system are implemented. Date filtering uses browser-local date versus ISO UTC timestamps and may need refinement near midnight.
